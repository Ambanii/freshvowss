from aiogram import Router
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from states.user import UserState
from utils.validators import valid_age

router = Router()

@router.message(UserState.age)
async def get_age(msg: Message, state: FSMContext):
    if not msg.text.isdigit() or not valid_age(int(msg.text)):
        await msg.answer('Enter valid age (18+)')
        return
    await state.update_data(age=int(msg.text))
    await msg.answer('Your city?')
    await state.set_state(UserState.city)
