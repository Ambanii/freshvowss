from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from states.user import UserState
from keyboards.language import language_keyboard
from utils import texts

router = Router()

@router.message(F.text == '/start')
async def start_cmd(msg: Message, state: FSMContext):
    await msg.answer(texts.LANG_SELECT, reply_markup=language_keyboard())
    await state.set_state(UserState.language)
