from aiogram.fsm.state import StatesGroup, State

class UserState(StatesGroup):
    language = State()
    age = State()
    gender = State()
    city = State()
