LANG_SELECT = 'Choose your language 👇'
WELCOME = 'Already millions of people meet in Leomatchbot 😍'